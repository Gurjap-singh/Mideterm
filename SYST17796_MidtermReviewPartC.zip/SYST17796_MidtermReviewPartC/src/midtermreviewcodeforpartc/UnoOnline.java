package midtermreviewcodeforpartc;

import java.util.Scanner;

public class UnoOnline {

    private final User[] users = new User[100]; // room for 100 online players!

    // Messages as constants (easy to change later)
    private static final String MSG_RULES_LINE_1 = "Passwords must have at least 8 characters";
    private static final String MSG_RULES_LINE_2 = "Passwords must have at least one special character";
    private static final String MSG_PROMPT_USERNAME = "Please enter your desired user name: ";
    private static final String MSG_PROMPT_PASSWORD = "Please enter your desired password: ";
    private static final String MSG_ACCEPTED = "Password accepted!";
    private static final String MSG_INVALID = "Invalid password. Try again.";

    public static void main(String[] args) {
        new UnoOnline().run();
    }

    /**
     * Method that takes the user's name and chosen password and keeps prompting
     * until the password is valid based on these rules:
     * 1) Length >= 8
     * 2) Contains at least one special character
     */
    private void run() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print(MSG_PROMPT_USERNAME);
            String userName = sc.nextLine().trim();

            PasswordValidator validator = new PasswordValidator();
            String password = promptForValidPassword(sc, validator);

            // Optionally create/store the user
            // users[0] = new User(userName, password);

            System.out.println("Welcome, " + userName + "! You have been registered.");
        }
    }

    /**
     * Repeatedly prompts for a password until the validator accepts it.
     */
    private String promptForValidPassword(Scanner sc, PasswordValidator validator) {
        while (true) {
            System.out.println(MSG_RULES_LINE_1);
            System.out.println(MSG_RULES_LINE_2);
            System.out.print(MSG_PROMPT_PASSWORD);

            String candidate = sc.nextLine();

            if (validator.validate(candidate)) {
                System.out.println(MSG_ACCEPTED);
                return candidate;
            }
            System.out.println(MSG_INVALID);
        }
    }
}
