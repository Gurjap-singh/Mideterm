package midtermreviewcodeforpartc;

/**
 * PasswordValidator
 *
 * Design:
 * - Single Responsibility Principle (SRP): This class only validates passwords.
 * - Open/Closed Principle (OCP): New rules can be added as new methods.
 * - Encapsulation: Validation logic is hidden from the rest of the program.
 *
 * Current rules:
 * 1. Password must be at least 8 characters.
 * 2. Password must contain at least one special character.
 */
public class PasswordValidator {

    public PasswordValidator() {
    }

    public boolean validate(String password) {
        return isLengthValid(password) && hasSpecialChar(password);
    }

    private boolean isLengthValid(String password) {
        return password != null && password.length() >= 8;
    }

    private boolean hasSpecialChar(String password) {
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return true;
            }
        }
        return false;
    }
}

